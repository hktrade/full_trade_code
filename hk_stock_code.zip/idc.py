import urllib.request,requests
from urllib import error
from socket import timeout
from datetime import datetime,timedelta
import pandas as pd
import numpy as np
from pandas.io.json import json_normalize
import sys,time,csv,os,os.path,json,re
import pandas_ta as ta
import datetime as dt
import pytz

from futu import *
quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11112)

ohlc_dict = {'open':'first', 'high':'max', 'low':'min', 'close':'last'}
k=0;endstr=''
def def_str(mystr):
	min2 = (datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
	inputstr='\n'+min2+','+str(mystr)
	if os.stat(r'str.csv').st_size == 0:
		f=open(r'str.csv','w');f.write(inputstr);f.close()
	else:
		f=open(r'str.csv','a+');f.write(inputstr);f.close()
	print(inputstr)	
def def_txt2(mystr):
	UTC = pytz.timezone('America/New_York')
	time_now = dt.datetime.now(tz=UTC)
	time_15_min_ago = time_now - dt.timedelta(days=2,minutes=15)
	min2=str(time_15_min_ago)
	inputstr='\n'+min2+'\t'+str(mystr)
	f=open(r'error.csv','a+');f.write(inputstr);f.close()
# ('UTC')
UTC = pytz.timezone('America/New_York')

def get_day(symbols):
	ret_sub, err_message = quote_ctx.subscribe(symbols, SubType.K_DAY, subscribe_push=False)
	if ret_sub == RET_OK:
		ret, data3 = quote_ctx.get_cur_kline(symbols, 250, SubType.K_DAY ,AuType.QFQ)
		if len(data3)<2 or ret==-1:
			def_str(symbols + '  kline error')
			return None
		df = data3.copy()
		df['time_key'] = pd.to_datetime(df['time_key'])
		df.set_index('time_key', inplace=True,drop=False)
		return df
	print(err_message)	
	

def get_bar_min_tdd(symbols, N):
	if symbols.find('HK.')==-1:
		symbols = 'HK.'+symbols
	ohlc_dict = {'open':'first', 'high':'max', 'low':'min', 'close':'last', 'volume':'sum'}

	futu_freq = [1,3,5,15,30,60]
	other_freq_A = [2,4,10]
	other_freq_B = [120,180,240,360,480,720]
	def codes(i):
		switcher={1:SubType.K_1M,3:SubType.K_3M,5:SubType.K_5M,15:SubType.K_15M,30:SubType.K_30M,60:SubType.K_60M}
		return (switcher.get(i,"Invalid Symbols"))

	K_type = N 

	org_K = str(K_type)
	if K_type in futu_freq:
		K_type = codes(K_type)
	elif K_type in other_freq_A:
		K_type = SubType.K_1M
	elif K_type in other_freq_B:
		K_type = SubType.K_60M
	elif K_type == 1440:
		K_type = SubType.K_DAY
	else:
		print('Error K_type');	
		def_str('Error K_type')
		return None

	ret_sub, err_message = quote_ctx.subscribe(symbols, K_type, subscribe_push=False)
	if ret_sub == RET_OK:
		ret, data3 = quote_ctx.get_cur_kline(symbols, 1000, K_type)

		if len(data3)<2 or ret==-1:
			def_str(symbols + '  kline error')
			return None

		df = data3.copy()
		df['time_key'] = pd.to_datetime(df['time_key'])
		df.set_index('time_key', inplace=True,drop=False)
		
		if K_type not in futu_freq or K_type != SubType.K_DAY :

			T_freq = org_K + 'T'
			dfH =  df.resample(T_freq, closed='left').agg(ohlc_dict).dropna(how='any')
			dfH['time_key'] = dfH.index
			data3 = dfH.copy()

		if ret !=-1:# the two lines for vwap

			df['vwap'] = df.ta.vwap()	
			# print(df.tail(5))
			return df

	print(err_message)	
def kdj(data): # 9,3,3
	p1 = 9
	p2 = 3
	p3 = 3
	data['llv_low']=data['low'].rolling(p1).min()
	data['hhv_high']=data['high'].rolling(p1).max()
	data['rsv']=(data['close']-data['llv_low'])/(data['hhv_high']-data['llv_low'])
	data['k']=(data['rsv'].ewm(adjust=False,alpha=1/p2).mean())
	data['d']=(data['k'].ewm(adjust=False,alpha=1/p3).mean())
	data['j']=3*data['k']-2*data['d']

	for j in range(8):
		data['k'].iloc[j]=0
		data['d'].iloc[j]=0
		data['j'].iloc[j]=0
		
	data['k'] =data.apply(lambda x: round(x['k']*100,2), axis=1)
	data['d'] =data.apply(lambda x: round(x['d']*100,2), axis=1)
	data['j'] =data.apply(lambda x: round(x['j']*100,2), axis=1)
	data=data.drop ('llv_low',axis=1)
	data=data.drop ('hhv_high',axis=1)
	data=data.drop ('rsv',axis=1)
	return data

def kdj_cross(df):
	ptx = 0
	if df['j'].iloc[-1] > df['d'].iloc[-1] and df['j'].iloc[-2] < df['d'].iloc[-2]:
		if df['j'].iloc[-2:].max() < 20:
			ptx = -10
			print('KDJ low level Gold')
	if df['d'].iloc[-1] > df['j'].iloc[-1] and df['d'].iloc[-2] < df['j'].iloc[-2]:
		if df['j'].iloc[-2:].min() > 80:
			ptx = 100
			print('KDJ high level Death')
	return ptx
	
def boll(df):
	df=df.copy()
	df['20sma'] = df['close'].rolling(window=20).mean()
	df['stddev'] = df['close'].rolling(window=20).std()
	df['bbh'] = df['20sma'] + (2.5 * df['stddev'])
	df['bbl'] = df['20sma'] - (2.2 * df['stddev'])

	df['TR'] = abs(df['high'] - df['low'])
	df['ATR'] = df['TR'].rolling(window=20).mean()

	df['20ema'] =df['close'].ewm(span=20, min_periods=20).mean()
	return(df)
	
def boll_cross(df):
	bbh = 0;	bbl = 0;	bbm_greater = 0;	bbm_less = 0
	bbh = len(df[df['close']>df['bbh']])
	bbl = len(df[df['close']<df['bbl']])
	bbm_greater = len(df[df['close']>df['20ema']])
	bbm_less = len(df[df['close']<df['20ema']])
	vwap_greater = len(df[df['close']>df['vwap']])
	vwap_less = len(df[df['close']<df['vwap']])
	print('bbh,bbl,bbm_greater,bbm_less,vwap_greater,vwap_less')
	print(bbh,bbl,bbm_greater,bbm_less,vwap_greater,vwap_less)
	print('\n')
	print(df['close'].iloc[-1], round(df['bbh'].iloc[-1]-df['close'].iloc[-1],2), round(df['close'].iloc[-1]-df['bbl'].iloc[-1],2))
	return(str(bbh) +','+ str(bbl)+ ','+ str(bbm_greater) +','+ str(bbm_less)+ ','+ 
	str(vwap_greater) +','+ str(vwap_less) +','+ str(df['close'].iloc[-1])+ ','+
	str(round(df['bbh'].iloc[-1]-df['close'].iloc[-1],2))+ ','+str(round(df['close'].iloc[-1]-df['bbl'].iloc[-1],2)))

def matrix(df):
	df['vwap'] = df.ta.vwap()
	df = kdj(df)
	df = boll(df)
	df['ma5'] = ta.sma(close=df['close'], length=5)
	df['ma10'] = ta.sma(close=df['close'], length=10) # 1000 // 60 = 16
	print(df.keys())
	return(df)
def ema_x(df, n):
    EMA = pd.Series(df['close'].ewm(span=n, min_periods=n).mean(), name='ema_' + str(n))
    df = df.join(EMA)
    return df['ema_' + str(n)].iloc[-1]
def get_ema(hlc):
	avg10=(ema_x(hlc,10));avg20=(ema_x(hlc,20))
	avg30=(ema_x(hlc,30));avg40=(ema_x(hlc,40));avg50=(ema_x(hlc,50));avg60=(ema_x(hlc,60))
	avg70=(ema_x(hlc,70));avg80=(ema_x(hlc,80));avg90=(ema_x(hlc,90));avg100=(ema_x(hlc,100))
	avg120=(ema_x(hlc,120));avg140=(ema_x(hlc,140));avg160=(ema_x(hlc,160));avg180=(ema_x(hlc,180))
	avg200=(ema_x(hlc,200));
	SAVE_X='0'
	if avg10>avg20:
		SAVE_X='20'
		if avg20>avg30:
			SAVE_X='30'
			if avg30>avg40:
				SAVE_X='40'
				if avg40>avg50:
					SAVE_X='50'
					if avg50>avg60:
						SAVE_X='60'
						if avg60>avg70:
							SAVE_X='70'
							if avg70>avg80:
								SAVE_X='80'
								if avg80>avg90:
									SAVE_X='90'
									if avg90>avg100:
										SAVE_X='100'
										if avg100>avg120:
											SAVE_X='120'
											if avg120>avg140:
												SAVE_X='140'
												if avg140>avg160:
													SAVE_X='160'
													if avg160>avg180:
														SAVE_X='180'
														if avg180>avg200:
															SAVE_X='200'																
	elif avg10<avg20:
		SAVE_X='-20'
		if avg20<avg30:
			SAVE_X='-30'
			if avg30<avg40:
				SAVE_X='-40'
				if avg40<avg50:
					SAVE_X='-50'
					if avg50<avg60:
						SAVE_X='-60'
						if avg60<avg70:
							SAVE_X='-70'
							if avg70<avg80:
								SAVE_X='-80'
								if avg80<avg90:
									SAVE_X='-90'
									if avg90<avg100:
										SAVE_X='-100'
										if avg100<avg120:
											SAVE_X='-120'
											if avg120<avg140:
												SAVE_X='-140'
												if avg140<avg160:
													SAVE_X='-160'
													if avg160<avg180:
														SAVE_X='-180'
														if avg180<avg200:
															SAVE_X='-200'
	return(SAVE_X)
# cond4 1����kdj���

# cond3 1���� VWAP ����
# cond3 = df_vwap_1.iloc[-1] > df_vwap_1.iloc[-2]

# cond2 1���� K�����̼� ���� 200���ߺ�VWAP
# cond2 = df['SMA'].iloc[-1] < df['close'].iloc[-1] > df_vwap_1.iloc[-1]

# cond1 3���� K�����̼� �ϴ� VWAP
	# cond1 = (df_3['close'].iloc[-2] < df_vwap_3.iloc[-2] and 
	# df_3['close'].iloc[-1] > df_vwap_3.iloc[-1])

# cond5 3���� K�����̼� ���� ����
	# cond5 = df_3['close'].iloc[-1] > df_3['SMA'].iloc[-1]

# cond6 3���� kdj���
	# cond6 = (df_3.ta.kdj()['K_9_3'].iloc[-2] < df_3.ta.kdj()['D_9_3'].iloc[-2] and 
	# 45 > df_3.ta.kdj()['K_9_3'].iloc[-1] > df_3.ta.kdj()['D_9_3'].iloc[-1])