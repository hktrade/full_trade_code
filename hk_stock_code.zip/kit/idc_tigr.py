﻿import json,sys,csv,time,re,os
import pandas as pd
from datetime import datetime,timedelta
from idc import *
from futu import *
quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11112)
try:
	trd_ctx = OpenHKTradeContext(host='127.0.0.1', port=11112)
except:
	trd_ctx = OpenHKTradeContext(host='127.0.0.1', port=11112,
	is_encrypt = False, security_firm=SecurityFirm.FUTUSECURITIES)
	
def get_lot(symbol):
	ret, data = quote_ctx.get_stock_basicinfo(Market.HK, SecurityType.STOCK, symbol)
	if ret == RET_OK:
		# print(symbol,data['lot_size'][0])
		return(data['lot_size'][0])
	else:
		return None
	
def def_str(mystr):
	min2 = (datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
	inputstr='\n'+min2+','+str(mystr)
	if os.stat(r'str.csv').st_size == 0:
		f=open(r'str.csv','w',encoding='utf-8');f.write(inputstr);f.close()
	else:
		f=open(r'str.csv','a+',encoding='utf-8');f.write(inputstr);f.close()
	
def def_txt(mystr):
	min2 = (datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
	inputstr='\n'+min2+','+str(mystr)
	if os.stat(r'error.csv').st_size == 0:
		f=open(r'error.csv','w',encoding='utf-8');f.write(inputstr);f.close()
	else:
		f=open(r'error.csv','a+',encoding='utf-8');f.write(inputstr);f.close()
		
def get_pos_qty(symbol,TRD_ENV):	# 获取某只标的的 可卖数量
	if symbol.find('HK.')==-1:
		symbol='HK.'+symbol
	ret=-1;	ret_i=0
	while ret==-1:
		ret_i += 1
		if ret_i > 2:
			def_str(' get_pos_qty error >2 ')
			break
		time.sleep(3.1)
		ret,data_pos = trd_ctx.position_list_query(code=symbol, trd_env=TRD_ENV, refresh_cache=True)
		if ret==-1:
			def_str(' get_pos_qty '+str(data_pos));		time.sleep(3.1)
	pos_num=0
	if ret == RET_OK and len(data_pos)>0:
		pos_num=data_pos['can_sell_qty'].iloc[-1]
		
		tp_amount = 0; tp_rate = 0
		if pos_num > 0:
			tp_amount = data_pos['nominal_price'].iloc[-1] - data_pos['cost_price'].iloc[-1]
			tp_percent = (data_pos['nominal_price'].iloc[-1] - data_pos['cost_price'].iloc[-1]) / data_pos['cost_price'].iloc[-1]
			tp_rate = round(tp_percent,3)
		
		if pos_num > 0:
			return(['long', pos_num,tp_amount,tp_rate])
			
	return(['empty',0,0,0])

def read_local(symbol):
	pos_path = 'error.csv'
	if os.stat(pos_path).st_size == 0:
		return pd.DataFrame({})
	df_pos = pd.read_csv(pos_path, engine='python', header=None, 
	names=['time_key','symbol','act','quantity','oc'])
	df_pos = df_pos[df_pos['symbol'] == symbol]
	return(df_pos)
def read_act(symbol):
	pos_path = 'error.csv'
	if os.stat(pos_path).st_size == 0:
		return pd.DataFrame({})
	try:
		df_pos = pd.read_csv(pos_path, engine='python', header=None, 
		names=['time_key','symbol','act','quantity','oc'])
		df_pos = df_pos[df_pos['symbol'] == symbol]
		return(df_pos[['act','oc']].iloc[-1]['act'], df_pos[['act','oc']].iloc[-1]['oc'])
	except Exception as e:
		def_str('read_act error '+str(e))
		return None
def read_local_last():
	pos_path = 'error.csv'
	df_pos = pd.read_csv(pos_path, engine='python', header=None, 
	names=['time_key','symbol','act','quantity','oc'])
	if len(df_pos)>0:
		return(df_pos.iloc[-1])
	else:
		return(pd.DataFrame({}))
	
def get_minutes(a,b):
	return((pd.to_datetime(a, format='%Y-%m-%d %H:%M:%S')-
	pd.to_datetime(b, format='%Y-%m-%d %H:%M:%S')).seconds/60)

def get_now(symbol):
	df_loc = read_local(symbol)
	if len(df_loc)>0:
		try:
			b = df_loc[(df_loc['oc'] == 'open')]['time_key'].iloc[-1]
			return((datetime.now()-
			pd.to_datetime(b, format='%Y-%m-%d %H:%M:%S')).seconds/60)
		except:
			return -1
	return -1

def get_hk(symbol):
	print(symbol)
	if 'HK.' in symbol:
		symbol = symbol.replace('HK.','')
	print(symbol)
	temp_url = 'https://qt.gtimg.cn/q=r_hk' + symbol
	try:
		res = requests.get(temp_url, timeout=1.5)
	except Timeout:
		print('请求超时 except eastmoney HK')
		return None
	try:
		res_l = res.text.split('\n')[:-1]
		df = pd.DataFrame([r.replace('"', '').replace(';', '').split('~') for r in res_l])
		# print(res_l,type(res_l))
		key = res_l[0].split('~')
		print(key[-15])
		df = df[df.columns[:len(['code_ft', 'name', 'code', 'last', 'lastday'])]]
		df.columns = ['code_ft', 'name', 'code', 'last', 'lastday',]	
		df['code_ft']=df['code_ft'].str.replace('v_r_hk','HK.')#v_r_hk09969=100
		df['code_ft']=df['code_ft'].str.replace('=100','')
		df['qty'] = int(key[-15])
		df.dropna(inplace=True)
		df['last'] = df['last'].astype(float)
		df['lastday'] = df['lastday'].astype(float)
	except:
		df = None	
	return df
# cash = 30000
# px = (get_hk('00700')['last'].iloc[-1])
# qty = (get_hk('00700')['qty'].iloc[-1])
# print(get_hk('01810'))
# print(type(px))
# sys.exit()

def get_qty(cash, px, qty):
	if 1>0:
	# try:
		real_qty = cash // ( px * qty )
		return(real_qty * qty)
	# except:
		# return(0)
		
def ema_(df, n):# EMA函数
	my_name='temp'
	if n==13:
		my_name='Fast'
	elif n==3:
		my_name='Slow'
	EMA = pd.Series(df['temp'].ewm(span=n, min_periods=n).mean(), name=my_name)
	df = df.join(EMA)
	return df

def new18(df):# 升级版KD策略的函数之一
	N=18;	M1=1
	df['var3']=df['low'].rolling(N).min()	
	df['var4']=df['high'].rolling(N).max()
	df['temp'] = (df['close']-df['var3'])/(df['var4']-df['var3'])*100		# df = df.fillna(0)
	df=ema_(df,13);		df.drop(df.index[0:29], axis=0, inplace=True);		df.reset_index(drop=True, inplace=True)		
	df_tmp = [];	i = 0; y = 0
	while i < M1: 
		y = df['Fast'].iloc[i]
		df_tmp.append(y) 
		i = i + 1
	while i < len(df['Fast']):  
		y = df['Fast'].iloc[i-M1]
		df_tmp.append(y)  
		i = i + 1
	df['temp'] = 0.618 * pd.Series(df_tmp) + 0.382 * df['Fast']

	df=ema_(df, 3)
	return(df[['Fast','Slow']])

def CROSS(df):# 升级版KD策略的函数之一 ，返回 -10 代表作多 ， 返回 100 代表做空
	if df['Fast'].iloc[-1]>df['Slow'].iloc[-1] and df['Fast'].iloc[-2]<df['Slow'].iloc[-2]:
		return(-10)
	elif df['Fast'].iloc[-1]<df['Slow'].iloc[-1] and df['Fast'].iloc[-2]>df['Slow'].iloc[-2]:
		return(100)
	else:
		return(0)

def clear_all(TRD_ENV):
	trd_ctx.cancel_all_order()
	ret,data_q = trd_ctx.position_list_query(trd_env=TRD_ENV, refresh_cache=True)
	if ret == RET_OK and len(data_q)>0:
		time.sleep(3)
		for i in range(len(data_q)):
			if data_q['code'].iloc[i].find('HK.0')==-1:
				continue
			print(data_q['code'].iloc[i]+'  '+str(data_q['can_sell_qty'].iloc[i]))							
			ret, data_px = quote_ctx.get_market_snapshot(data_q['code'].iloc[i])
			def_str(data_q['code'].iloc[i]+'  k%120');		time.sleep(3)
			if ret == RET_OK and len(data_px)>0:								
				ret,data_err=trd_ctx.place_order(price=data_px['bid_price'][0], qty=data_q['can_sell_qty'].iloc[i], code=data_q['code'].iloc[i], trd_side=TrdSide.SELL, trd_env=TRD_ENV, remark='Auto cb1')
				def_str(str(ret));		time.sleep(3)