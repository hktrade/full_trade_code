from futu import *
import numpy as np
import time
import sys
import datetime
from matplotlib.pylab import date2num
import pandas as pd
from idc import *
quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11112)

if (str(sys.argv).find('-a')!=-1):

	min1=r'2021-09-23 15:10:00'
	min2=r'2021-09-23 15:59:00'
	
	code1='HK.00939'
	ret, data9, page_req_key = quote_ctx.request_history_kline(code1, start=min1, end=min2, ktype=KLType.K_1M)

	print(three(data9, 2))
	
	quote_ctx.close()
	sys.exit()

		
def idc_pv(df_idc, df_m1, N):
	start = 0;		codes=[];		old_N = N - 1
	df_find = pd.DataFrame({})
	for symbol in list(df_idc['code']):
		df_pv = df_m1[df_m1['code']==symbol]

		df_pv['turn1'] = df_pv['turnover'].shift(-1) - df_pv['turnover'].copy()
		df_pv['last1'] = df_pv['last_price'].shift(-1) - df_pv['last_price'].copy()
		df_pv.reset_index(drop=True, inplace=True)
		df_pv.dropna(inplace=True)

		if len(df_pv) <= old_N:
			continue
		while N > 1:	
			if (df_pv['last1'].iloc[-1-start] > df_pv['last1'].iloc[-1-start-1] and 
			df_pv['turn1'].iloc[-1-start] > df_pv['turn1'].iloc[-1-start-1]):
				start += 1
			else:				
				break
			N -= 1
		if start == old_N:
			df_find = df_find.append(df_pv.iloc[-1])
	return(df_find)
quote_ctx.close()
sys.exit()
