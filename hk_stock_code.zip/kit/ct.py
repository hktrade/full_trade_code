﻿from futu import *
from datetime import datetime,timedelta
from PyQt5.QtCore import QThread ,  pyqtSignal,  QDateTime , QObject,Qt,QRegExp
from PyQt5.QtWidgets import QButtonGroup,QPushButton,QApplication, QLineEdit,QGridLayout,QWidget,QCheckBox,QLabel,QListWidget,QRadioButton
from PyQt5.QtGui import QRegExpValidator
import os,os.path,time,sys,csv,json
from idc_tigr import *
from idc import *

k=-1;	symbols=[];		start_list=[]; 		stop_list=[];	
ospath = os.path.abspath(os.path.dirname(__file__))
wk=datetime.today().weekday();min2=datetime.now().strftime('%Y-%m-%d %H:%M')+':00'
df_total = pd.DataFrame({});	df_cfg = pd.DataFrame({});		df_one = pd.DataFrame({})
config_df = ['symbol','open_cap_rate','open_qty','open_freq','open_gap','close_hold','with_idc','m_close','stop']

setdata = read_set()
print('password: \t',setdata.password[0], '\n cash: \t\t',setdata.cash[0], '\n TRD_ENV: \t',setdata.TRD_ENV[0])

TRD_ENV = setdata.TRD_ENV[0]
class BackendThread(QObject):
	update_date = pyqtSignal(str)
	def run(self):
		while True:
			data = QDateTime.currentDateTime()
			currTime = data.toString("yyyy-MM-dd hh:mm:ss")
			self.update_date.emit( str(currTime) )
			time.sleep(1)

class Window(QWidget):
	def __init__(self):
		QWidget.__init__(self)
		global k
		grid = QGridLayout();
		self.symbol_list=QListWidget(self);
		self.Label_set0=QLabel('当前股票代码',self);			
		self.symbol=QLineEdit(self);
		self.Label_set2=QLabel('开仓资金比例%',self);self.open_cap_rate=QLineEdit('10',self);		
		self.open_qty=QLineEdit('0',self);
		self.Label_set5=QLabel('K线频率',self);			
		self.open_freq=QLineEdit('3',self);			
		self.Label_set7=QLabel('开仓间隔时间',self);
		self.open_gap=QLineEdit('0',self);		
		self.Label_set8=QLabel('平仓持仓时间',self);
		self.close_hold=QLineEdit('0',self);

		self.Label_set9=QLabel('开仓策略设定',self);self.cb_CROSS=QCheckBox(" KD 策略  ",self)
	
		self.Label_set12=QLabel('收盘前平仓(分钟)',self);	self.m_close=QLineEdit('5',self);
		self.m_cross=QCheckBox("是否跨盘  ",self);

		self.Trd=QCheckBox("真实交易",self);
		self.start_btn=QPushButton('单个开始');			self.stop_btn=QPushButton('单个停止');
		self.close_btn=QPushButton('单个平仓')
		self.cb1_btn=QPushButton('&Q 全部停止');
		self.R_btn3=QPushButton('&R 保存')
		self.G_btn2=QPushButton('&H 全部平仓');			self.R_btn2=QPushButton('&T 清除')
		self.R_btn1=QPushButton('&Y 全部开始')
		self.load_btn=QPushButton('查询配置');

		grid.addWidget(self.load_btn, 20, 4, 1, 1);
		grid.addWidget(self.R_btn3, 18, 4, 1, 1);
		grid.addWidget(self.G_btn2, 20, 6, 1, 1);	grid.addWidget(self.R_btn2, 19, 4, 1, 1);
		grid.addWidget(self.R_btn1, 18, 6, 1, 1);
		grid.addWidget(self.start_btn, 18, 5, 1, 1);grid.addWidget(self.cb1_btn, 19, 6, 1, 1);
		grid.addWidget(self.stop_btn, 19, 5, 1, 1); grid.addWidget(self.close_btn, 20, 5, 1, 1);
		self.cb1_btn.clicked.connect(lambda :self.whichbtn(self.cb1_btn))
		self.R_btn3.clicked.connect(lambda :self.whichbtn(self.R_btn3))
		self.G_btn2.clicked.connect(lambda :self.whichbtn(self.G_btn2));self.R_btn2.clicked.connect(lambda :self.whichbtn(self.R_btn2))
		self.start_btn.clicked.connect(lambda :self.whichbtn(self.start_btn));self.stop_btn.clicked.connect(lambda :self.whichbtn(self.stop_btn))	
		self.close_btn.clicked.connect(lambda :self.whichbtn(self.close_btn));self.load_btn.clicked.connect(lambda :self.whichbtn(self.load_btn))	
		self.R_btn1.clicked.connect(lambda :self.whichbtn(self.R_btn1));self.load_btn.clicked.connect(lambda :self.whichbtn(self.load_btn))	

		self.config_list=QListWidget(self);

		grid.addWidget(self.Label_set0,4,4,1,1);	grid.addWidget(self.symbol,4,5,1,1);
		grid.addWidget(self.Label_set2,6,4,1,1);	
		grid.addWidget(self.open_cap_rate, 6,5,1,1);grid.addWidget(self.open_qty, 6,6,1,1);			

		grid.addWidget(self.Label_set5,8,4,1,1);	grid.addWidget(self.open_freq,8,5,1,1);
		grid.addWidget(self.Label_set7,10,4,1,1);	grid.addWidget(self.open_gap,10,5,1,1);
		grid.addWidget(self.Label_set8,12,4,1,1);	grid.addWidget(self.close_hold,12,5,1,1);
		grid.addWidget(self.Label_set9,14,4,1,1);	grid.addWidget(self.cb_CROSS,14,5,1,1);

		grid.addWidget(self.Label_set12,16,4,1,1);	grid.addWidget(self.m_close,16,5,1,1);   grid.addWidget(self.m_cross,16,6,1,1);
########
		self.setWindowTitle('Client');
		self.trade_list=QListWidget(self);			self.Label_ID_req=QLabel("Account",self)

		self.cb1=QCheckBox("清理",self);			self.lb_Time=QLabel("time",self)
		# grid.addWidget(self.cb_LONG, 31,4,1,1);		grid.addWidget(self.cb_SHORT, 31,5,1,1);
		grid.addWidget(self.trade_list,4,0,14,4);	grid.addWidget(self.Label_ID_req, 33, 4, 1, 4);		
		grid.addWidget(self.symbol_list,18,0,3,4);				
		grid.addWidget(self.config_list,20,0,8,4);
		#(1, 0, 1, 2)    第1行,第0列,占用1行,占用2列
		grid.addWidget(self.lb_Time, 33, 0, 1, 1);grid.addWidget(self.cb1, 33, 1, 1, 1);	
		grid.addWidget(self.Trd, 33, 3, 1, 1);		

		self.setLayout(grid);self.resize(500, 580)

		self.setWindowTitle('kit 港股交易程式 (WX QQ 1013001850)');
		
		self.initUI()
		
	def whichbtn(self,btn):
		global trade_list, df_total, symbols, k, df_cfg, start_list, stop_list, TRD_ENV

		if btn.text() == '查询配置':
			if self.symbol_list.currentItem() is None:
				def_str('currentItem None return')
				self.config_list.addItems(['错误：未选取代码']);return
			df_cfg = read_config()
			if df_cfg is None:
				def_str('df_cfg None return');return
			print('\n len\t',len(df_cfg), '\t df_cfg \n Load settings !\n')

			df = df_cfg[df_cfg['symbol']==self.symbol_list.currentItem().text()]
			
			self.symbol.setText(df['symbol'][0])

			if  df['m_close'][0]>0:
				self.m_cross.setChecked(False)
			elif df['m_close'][0]==0:
				self.m_cross.setChecked(True)
				
			self.open_cap_rate.setText(str(df['open_cap_rate'][0]))
			self.open_qty.setText(str(df['open_qty'][0]))
			# self.short_limit.setText(str(df['short_limit'][0]))
			self.open_freq.setText(str(df['open_freq'][0]))
			self.open_gap.setText(str(df['open_gap'][0]))
			self.close_hold.setText(str(df['close_hold'][0]))
			self.m_close.setText(str(df['m_close'][0]))

			self.config_list.addItems([df['symbol'][0] + '  查询配置'])

		elif btn.text() == '&T 清除':
			if self.symbol_list.currentItem() is None:
				print('None return')
				self.config_list.addItems(['错误：未选取代码']);return

			value = self.symbol_list.currentItem().text()+'.csv'
			sym = self.symbol_list.currentItem().text()
			print("delete file : " + str(value))
			os.remove('config/'+value)
			
			self.symbol_list.clear()
			symbols = file_name_walk('config/')
			if len(symbols)>0:
				for i in range(len(symbols)):
					symbols[i] = symbols[i].replace('.csv','')			
					self.symbol_list.addItems([symbols[i]])
					
			self.config_list.addItems([sym + '  清除'])

		elif btn.text()=='&R 保存':
			if self.symbol_list.currentItem() is None:
				print('None return')
				self.config_list.addItems(['错误：未选取代码']);return
			with_idc='?'
			if self.cb_CROSS.isChecked():
				with_idc = 'KD'

			df_hk = get_hk(self.symbol_list.currentItem().text());	
			open_qty = 0
			qty = get_lot(self.symbol_list.currentItem().text())
			# print(qty)
			px = df_hk['last'].iloc[-1]
			# qty = df_hk['qty'].iloc[-1]
			cash = int(setdata.cash[0])*int(self.open_cap_rate.text())/100
			open_qty = get_qty(cash, px, qty)
			print(setdata.cash[0],px,qty)
			print(self.symbol.text(),'\t px qty \t',px,open_qty,'\n')
			
			self.open_qty.setText(str(open_qty))
			rows = [[self.symbol.text(), self.open_cap_rate.text() ,self.open_qty.text() ,
			self.open_freq.text(),self.open_gap.text(),self.close_hold.text(),
			with_idc,self.m_close.text(),'True']]

			df = pd.DataFrame(rows, columns=config_df)
			df.to_csv('config/'+self.symbol.text()+'.csv', index=False, mode='w',columns=config_df)
			df_total = df_total.append(df)
			print(df_total)

			# old_row = self.symbol_list.selectedItems()

			self.symbol_list.clear()
			symbols = file_name_walk('config/')
			if len(symbols)>0:
				for i in range(len(symbols)):
					symbols[i] = symbols[i].replace('.csv','')			
					self.symbol_list.addItems([symbols[i]])
					print([symbols[i]])
			
			start_list.append(self.symbol.text())

			self.config_list.addItems([self.symbol.text() + '  保存'])
			
			# self.symbol_list.setCurrentItem(old_row)
			
		elif btn.text() == '&Y 全部开始':			
			df_cfg = read_config()
			print('\n len\t',len(df_cfg), '\t df_cfg \n \t\t\t\t\tBegin trading !\n', df_cfg['symbol'])
			
			if (sum(df_cfg.isnull().sum()) > 0):
				print(' conifg isnull ! ', k)
				print(df_cfg.isnull().sum())
				return
				
			for i in range(len(list(df_cfg['symbol']))):	
				df = df_cfg[df_cfg['symbol'] == df_cfg['symbol'].iloc[i]]
				df.at[0, ['stop']] = 'False'
				df.to_csv('config/'+df_cfg['symbol'].iloc[i]+'.csv', index=False, mode='w',columns=config_df)
			self.config_list.addItems(['全部开始'])		
			k=0
		elif btn.text() == '&Q 全部停止':
			k=-1
			stop_all()
			self.config_list.addItems(['全部停止'])	

		elif btn.text() == '&H 全部平仓' :
			print('\n Clear all orders \n')
			df_clr = clear_all(TRD_ENV)
			if len(df_clr)>0:
				for i in range(len(df_clr)):
					self.trade_list.addItems([df_clr['symbol'].iloc[i]+' '+df_clr['act'].iloc[i]+' '+str(df_clr['quantity'].iloc[i])+' '+df_clr['oc'].iloc[i]])
			self.config_list.addItems(['全部平仓'])
		elif btn.text() == '单个开始':
			if self.symbol_list.currentItem() is None:
				print('None return')
				self.config_list.addItems(['错误：未选取代码']);return
			print('start \t', self.symbol_list.currentItem().text())			
			df_cfg = read_config()			
			df = df_cfg[df_cfg['symbol'] == self.symbol_list.currentItem().text()]
			df.at[0, ['stop']] = 'False';	print(df['stop'])
			df.to_csv('config/'+self.symbol_list.currentItem().text()+'.csv', index=False, mode='w',columns=config_df)
			k=0
			self.config_list.addItems([self.symbol_list.currentItem().text() + '  单个开始'])	
		elif btn.text() == '单个停止':
			if self.symbol_list.currentItem() is None:
				print('None return')
				self.config_list.addItems(['错误：未选取代码']);return
			print('stop \t',self.symbol_list.currentItem().text())
			df_cfg = read_config()			
			df = df_cfg[df_cfg['symbol'] == self.symbol_list.currentItem().text()]
			df.at[0,'stop'] = 'True';	print(df['stop'])
			df.to_csv('config/'+self.symbol_list.currentItem().text()+'.csv', index=False, mode='w',columns=config_df)
			self.config_list.addItems([self.symbol_list.currentItem().text() + '  单个停止'])	
			
		elif btn.text() == '单个平仓':	
			if self.symbol_list.currentItem() is None:
				print('None return')
				self.config_list.addItems(['错误：未选取代码']);return
			self.config_list.addItems([self.symbol_list.currentItem().text() + '  单个平仓'])	
			print('\n Clear '+self.symbol_list.currentItem().text()+'\n')
			clear_all(self.symbol_list.currentItem().text())		

	def closeEvent(self, event):
		stop_all()
		sys.exit()
			
	def initUI(self):
		self.backend = BackendThread()
		self.backend.update_date.connect(self.handleDisplay)
		self.thread = QThread()
		self.backend.moveToThread(self.thread)
		self.thread.started.connect(self.backend.run)
		self.thread.start()		
		
	def handleDisplay(self, data):
		global ospath, config_df, df_total, min2, k, symbols, df_cfg, start_list, stop_list, df_one
		comb=''+str(datetime.now())[11:19];		self.lb_Time.setText(comb);
			
		if self.cb1.isChecked()==True:			
			self.cb1.setChecked(False)
			f=open(r'str.csv','w');f.write('');f.close();
			f=open(r'error.csv','w');f.write('');f.close();		print('clear error.csv log')

		if self.Trd.isChecked()==True:
			Trd_type='.REAL';TRD_ENV=TrdEnv.REAL
			self.Label_ID_req.setText('真实')
		else:
			Trd_type='.SIMULATE';TRD_ENV=TrdEnv.SIMULATE
			self.Label_ID_req.setText('模拟')

		if self.symbol_list.count()==0:
			self.symbol_list.clear()
			symbols = file_name_walk('config/')
			if len(symbols)>0:
				for i in range(len(symbols)):
					symbols[i] = symbols[i].replace('.csv','')			
					self.symbol_list.addItems([symbols[i]])

		if (k==-1 or k==0) or k%3==0:
			df_one = df_one.append(read_local_last())#'symbol','act','quantity','oc
			if len(df_one) == 0:return
			if len(df_one)>1 and (df_one['time_key'].iloc[-2] == df_one['time_key'].iloc[-1])==False:
				self.trade_list.addItems([df_one['symbol'].iloc[-1]+' '+str(df_one['act'].iloc[-1])+' '+str(df_one['quantity'].iloc[-1])+' '+df_one['oc'].iloc[-1]])
#2022-01-14 09:30:51,HK.00732,sell,6000,close
# names=['time_key','symbol','act','quantity','oc'])
			if len(df_one)>9:
				df_one = df_one.iloc[-9:]

			count = self.trade_list.count()
			if count>1 and k!=-2:
				try:
					if self.trade_list.item(count-2).text() == self.trade_list.item(count-1).text():
						stop_all()
						k = -2
						self.trade_list.clear()
				except:
					print('alert error')
				
		if k%10 == 0:
			vsb = self.config_list.verticalScrollBar()	
			if vsb.value() <= vsb.maximum():vsb.setValue(vsb.value() + 2)	
			vsb = self.trade_list.verticalScrollBar()	
			if vsb.value() <= vsb.maximum():vsb.setValue(vsb.value() + 2)
		if k != -2:
			k += 1
#############

if __name__ == '__main__':
	app = QApplication(sys.argv)
	win = Window()	# win.setWindowFlags(Qt.WindowMinimizeButtonHint)
	win.move(680,0)
	win.show()
	sys.exit(app.exec_())