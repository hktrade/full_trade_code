import urllib.request,requests
from urllib import error
from socket import timeout
from datetime import datetime,timedelta
import pandas as pd
import numpy as np
from pandas.io.json import json_normalize
from futu import *
import sys,time,csv,os,os.path,json,re,pytz,warnings
import pandas_ta as ta
import datetime as dt
from idc import *
warnings.filterwarnings("ignore")
quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11112)
futu_freq = [1,3,5,15,30,60]

ohlc_dict = {'open':'first', 'high':'max', 'low':'min', 'close':'last'}
k=0;endstr=''

# heavyweights HSI
# No short
# rate 5%-8% , overnight 
# 60m, 3 pairs, 
# 00853?
# 06862 02618 01579
list10 = ['HK.09618', 'HK.00853', 'HK.01579', 'HK.00285', 
'HK.00981', 'HK.00753', 'HK.06862']

# 强势做短线 ？00853 00285 09618(hard)
# 震荡做短线 ？01579 06862 00753 00981
# 不做短线 ？01810 01833 02618 00939
# 牛熊证 ？ 
# +01810

def get_(symbol):
	ret_sub, err_message = quote_ctx.subscribe(symbol, KLType.K_1M, subscribe_push=False)
	if ret_sub == RET_OK:
		ret, data3 = quote_ctx.get_cur_kline(symbol, 1000, KLType.K_1M)
		df = data3[['code','time_key','open','close','high','low','volume']]
		df.index = pd.to_datetime(df['time_key'])
		return(df)
	else:
		print(err_message)

def getd(symbol):
	ret_sub, err_message = quote_ctx.subscribe(symbol, KLType.K_DAY, subscribe_push=False)
	if ret_sub == RET_OK:
		ret, data3 = quote_ctx.get_cur_kline(symbol, 250, KLType.K_DAY)
		df = data3[['code','time_key','open','close','high','low','volume']]
		df.index = pd.to_datetime(df['time_key'])
		return(df)
	else:
		print(err_message)

def get_any(df,N_K):
	ohlc_dict = {'open':'first', 'high':'max', 'low':'min', 'close':'last', 'volume':'sum'}
	df['time_key'] = pd.to_datetime(df['time_key'])
	df_old = df['close'].iloc[-1]
	df.set_index('time_key', inplace=True,drop=False)
	T_freq = str(N_K) + 'T'
	dfH =  df.resample(T_freq, closed='left').agg(ohlc_dict).dropna(how='any')
	dfH['time_key'] = dfH.index
	data3 = dfH.copy()
	return(data3)
	
f=open(r'day.csv','w');f.write('');f.close();
f=open(r'm1.csv','w');f.write('');f.close();
f=open(r'm5.csv','w');f.write('');f.close();

def def_day(mystr,fn):
	inputstr='\n'+str(mystr)+' '
	f=open(fn+'.csv','a+');f.write(inputstr);f.close()
	
def_all = 'bbh'+','+'bbl'+','+'bbm_greater'+','+'bbm_less'+','+'vwap_greater'+','+'vwap_less'+','+'close'+','+'bbh-close'+','+'close-bbl'+','+'ema_x'+','+'code'
def_day(def_all,'day')
def_day(def_all,'m1')
def_day(def_all,'m5')

for symbol in list10:
	df = get_(symbol)
	df_m = matrix(df)

	def_all=boll_cross(df_m)+','+symbol+','+str(get_ema(df_m))
	def_day(def_all,'m1')
	
	df = get_any(df,5)
	df_m = matrix(df)
	def_all=boll_cross(df_m)+','+symbol+','+str(get_ema(df_m))
	def_day(def_all,'m5')
	
	df = getd(symbol)
	df_m = matrix(df)
	def_all=boll_cross(df_m)+','+symbol+','+str(get_ema(df_m))
	def_day(def_all,'day')

quote_ctx.close()
sys.exit()