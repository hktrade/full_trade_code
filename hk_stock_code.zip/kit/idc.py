import logging
import pandas as pd
import numpy as np
from datetime import datetime,timedelta
import json,sys,csv,time,os
import urllib,requests
from urllib.request import Request, urlopen
log = logging.getLogger(__name__)

config_list = ['symbol','open_cap_rate','open_qty','open_freq','open_gap','close_hold','with_idc','m_close','stop']
def read_config(symbol):
	files = file_name_walk('config/');	df_cfg=pd.DataFrame({})
	if len(files)==0:
		return None
	for i in range(len(files)):
		if files[i] == symbol+'.csv':
			df = pd.read_csv('config/'+files[i], dtype={'break_down': float, 
			'over_priced': float,'tp': float,'sl': float,
			'boll': float,'hand': float,'symbol': str,},engine='python')
			df = df.set_index('key')
			return(df)
	return None
	
def szm_hk(df):
	df=df.copy()
	df['20sma'] = df['close'].rolling(window=20).mean()
	df['stddev'] = df['close'].rolling(window=20).std()
	df['bbl'] = df['20sma'] - (2.2 * df['stddev'])
	df['bbh'] = df['20sma'] + (2.2 * df['stddev'])

	df['TR'] = abs(df['high'] - df['low'])
	df['ATR'] = df['TR'].rolling(window=20).mean()
	df['20ema'] =df['close'].ewm(span=20, min_periods=20).mean()
	return(df)

def szm_ptx(df, boll_int):
	if boll_int == -1:
		if df['close'].iloc[-2] < df['bbl'].iloc[-2] and df['close'].iloc[-1] > df['bbl'].iloc[-1] :
			return -10
	elif boll_int == 0:
		if df['close'].iloc[-2] < df['20ema'].iloc[-2] and df['close'].iloc[-1] > df['20ema'].iloc[-1] :
			return -10
	return 0
	
def szm_bbh(df, boll_int): # 1 is break top, 2 is break mid
	if boll_int == 1:
		if df['close'].iloc[-2] > df['bbh'].iloc[-2] and df['close'].iloc[-1] < df['bbh'].iloc[-1] :
			return 100
		if df['close'].iloc[-2] < df['bbl'].iloc[-2] and df['close'].iloc[-1] > df['bbl'].iloc[-1] :
			return -10
	elif boll_int == 0:
		if df['close'].iloc[-2] > df['20ema'].iloc[-2] and df['close'].iloc[-1] < df['20ema'].iloc[-1] :
			return 100
		if df['close'].iloc[-2] < df['20ema'].iloc[-2] and df['close'].iloc[-1] > df['20ema'].iloc[-1] :
			return -10
	return 0

def isnum(s):
    try:
        float(s)
        return True
    except ValueError:
        pass 
    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass 
    return False
	
def file_name_walk(file_dir):
	for root, dirs, files in os.walk(file_dir):
		len(files)
	return files	
	
def stop_all():
	df_cfg = read_config()
	print(df_cfg)
	if df_cfg is None:
		return
	for i in range(len(list(df_cfg['symbol']))):	
		df = df_cfg[df_cfg['symbol'] == df_cfg['symbol'].iloc[i]]
		df.at[0,'stop'] = 'True'
		df.to_csv('config/'+df_cfg['symbol'].iloc[i]+'.csv', index=False, mode='w',columns=config_list)
	print('\n len\t',len(df_cfg), '\t df_cfg \n \t\t\t\t\tStop trading !\n', df_cfg['symbol'])

def read_set():
	if os.path.isfile('setting/setting.csv') == False:
		return None		
	df = pd.read_csv('setting/setting.csv', dtype='str', engine='python')
	df['time_key'] = df.index
	return(df)

def read_season():	
	if os.path.isfile('setting/now.csv') == False:
		return None		
	df = pd.read_csv('setting/now.csv', dtype='str', engine='python')
	df['time_key'] = df.index
	print('start \t',df.start[0])
	print('end \t',df.end[0])
	return(df)