from datetime import datetime
import backtrader as bt# import backtrader.feeds as btfeeds
import json,os,sys
import requests
import yfinance as yf
import backtrader.feeds as btfeed
import backtrader.indicators as btind
from idc import *
# os.environ["http_proxy"] = "http://127.0.0.1:10809"
# os.environ["https_proxy"] = "http://127.0.0.1:10809"#7890

# Create a subclass of Strategy to define the indicators and logic

class TestStrategy(bt.Strategy):
	params = (
		("period", 20),
		("devfactor", 2.5),
		("size", 20),
		("debug", False)
	)

	def __init__(self):
		self.boll = bt.indicators.BollingerBands(period=self.p.period, devfactor=self.p.devfactor)
		print(self.data.close[0])

		self.vwap = self.data.open

		self.signal = btind.CrossOver(self.data.close, self.vwap)
	def next(self):
		if not self.position:
			if self.signal > 0 and self.data.high > self.boll.lines.mid:
				self.buy()
		else:
			if self.data.low > self.boll.lines.top and self.data.open > self.boll.lines.mid:
				self.close()


cerebro = bt.Cerebro()  # create a "Cerebro" engine instance
cerebro.broker.setcash(200000)

symbol = 'HK.00700'
if len(sys.argv)>2:
	df = get_bar_min_tdd(sys.argv[1], int(sys.argv[2]))
	symbol = sys.argv[1]
else:
	df = get_bar_min_tdd(symbol, 3)

print(len(df),df.tail(5))

def REF(tp1, n): # 通达信
    i = 0 
    ZB_l = []
    y = 0
    while i < n: 
        y=list(tp1)[i]   
        ZB_l.append(y) 
        i=i+1
    while i < len(tp1):  
        y=list(tp1)[i-n]
        ZB_l.append(y)  
        i = i + 1          #    ZB_s = pd.Series(ZB_l)  
    return pd.Series(ZB_l)
def barslast(lst):
    if sum(lst)>0: 
        first_=lst.index(1)
        bar_slast=[]
        for i in range(first_):
            bar_slast.append(np.nan)
        for i in range(first_,len(lst)):
            if lst[i]==1:
                count_=0
                bar_slast.append(0)
            else:
                count_+=1
                bar_slast.append(count_)
        return -bar_slast[-1]-1
		

def dibudunhua_ref(df, N1_new,M1_new):
	ref_bool = None
	
	df.drop(df.index[-1:], axis=0, inplace=True)
	df.reset_index(drop=True, inplace=True)
	
	N1 = barslast(N1_new[0:-1])
	M1 = barslast(M1_new[0:-1])
	CL1= df['close'].iloc[N1:].min()
	
	DIFL1 = df['dif'].iloc[N1:].min()

	N1_new2 = N1_new[0:N1]
	M1_new2 = M1_new[0:M1]
	N2 = barslast(N1_new2) + N1
	M2 = barslast(M1_new2) + M1
	print(M1,N1,N2,M2)

	CH1 = df['close'].iloc[M1:].max()
	DIFH1 = df['dif'].iloc[M1:].max()
	
	if abs(N1) > abs(M1) :
		CL2= df['close'].iloc[N1:M1+1].min()
		DIFL2= df['dif'].iloc[N1:M1+1].min()
		CH2 = df['close'].iloc[N1:M1+1].max()
		DIFH2 = df['dif'].iloc[N1:M1+1].max()
	elif abs(M1) > abs(N1):
		CL2= df['close'].iloc[M1:N1+1].min()
		DIFL2= df['dif'].iloc[M1:N1+1].min()
		CH2 = df['close'].iloc[M1:N1+1].max()
		DIFH2 = df['dif'].iloc[M1:N1+1].max()

	if abs(N2) > abs(M2) :
		CL3= df['close'].iloc[N2:M2+1].min()
		DIFL3= df['dif'].iloc[N2:M2+1].min()
		CH3 = df['close'].iloc[N2:M2+1].max()
		DIFH3 = df['dif'].iloc[N2:M2+1].max()
		
	elif abs(M2) > abs(N2): 
		CL3= df['close'].iloc[M2:N2+1].min()
		DIFL3= df['dif'].iloc[M2:N2+1].min()
		CH3 = df['close'].iloc[M2:N2+1].max()
		DIFH3 = df['dif'].iloc[M2:N2+1].max()

	zhijiedidunhua = CL1 < CL2 and DIFL1 > DIFL2 and df['macd'].iloc[-2] < 0 and df['dif'].iloc[-1] < 0
	gefengdidunhua = CL1 < CL3 and DIFL3 < DIFL1 < DIFL2 and df['macd'].iloc[-2] < 0 and df['dif'].iloc[-1] < 0
	dibudunhua = (zhijiedidunhua or gefengdidunhua) and df['dif'].iloc[-1] < 0
	
	ref_bool = (zhijiedidunhua or gefengdidunhua) and df['dif'].iloc[-1] < 0
	
	didunhua = (ref_bool == False and dibudunhua)
	dibujiegou = (ref_bool and (abs(df['dif'].iloc[-2]) >= abs(df['dif'].iloc[-1]) * 1.01))
	ref_bool2 = (dibujiegou==0 and dibujiegou)
	
	return ref_bool,ref_bool2
# 底结构形成 := ((REF(底部结构,1) = 0) AND 底部结构);
def macd(df_macd):
	df = df_macd.copy()	# df['close'] = df['close'].astype(float)
	df['short'] = df['close'].ewm(span=12, adjust=False).mean()
	df['long'] = df['close'].ewm(span=26, adjust=False).mean()
	df['dif'] = df['short'] - df['long']
	df['dea'] = df['dif'].ewm(span=9, adjust=False).mean()
	df['macd'] = (df['dif'] - df['dea']) * 2
	
	N1_a = np.where(REF(df['macd'], 1)>0 ,1,0).tolist()
	N1_b = np.where(df['macd']<0 ,1,0).tolist()
	N1_ab = list(np.array(N1_a) + np.array(N1_b))
	N1_new = [x//2 for x in N1_ab]
	
	M1_a = np.where(REF(df['macd'], 1)<0 ,1,0).tolist()
	M1_b = np.where(df['macd']>0 ,1,0).tolist()
	M1_ab = list(np.array(M1_a) + np.array(M1_b))
	M1_new = [x//2 for x in M1_ab]
###
	N1 = barslast(N1_new)
	M1 = barslast(M1_new)
	CL1= df['close'].iloc[N1:].min()
	
	print(N1_new[-30:])
	print(M1_new[-30:])
	
	DIFL1 = df['dif'].iloc[N1:].min()
	
	print(len(N1_new), -N1)
	N1_new2 = N1_new[0:N1]
	M1_new2 = M1_new[0:M1]
	N2 = barslast(N1_new2) + N1
	M2 = barslast(M1_new2) + M1
	print(M1,N1,N2,M2)
	print(df['dif'].tail(40))
	CH1 = df['close'].iloc[M1:].max()
	DIFH1 = df['dif'].iloc[M1:].max()
	
	if abs(N1) > abs(M1) :
		CL2= df['close'].iloc[N1:M1+1].min()
		DIFL2= df['dif'].iloc[N1:M1+1].min()
		CH2 = df['close'].iloc[N1:M1+1].max()
		DIFH2 = df['dif'].iloc[N1:M1+1].max()
	elif abs(M1) > abs(N1):
		CL2= df['close'].iloc[M1:N1+1].min()
		DIFL2= df['dif'].iloc[M1:N1+1].min()
		CH2 = df['close'].iloc[M1:N1+1].max()
		DIFH2 = df['dif'].iloc[M1:N1+1].max()

	if abs(N2) > abs(M2) :
		CL3= df['close'].iloc[N2:M2+1].min()
		DIFL3= df['dif'].iloc[N2:M2+1].min()
		CH3 = df['close'].iloc[N2:M2+1].max()
		DIFH3 = df['dif'].iloc[N2:M2+1].max()
		
	elif abs(M2) > abs(N2): 
		CL3= df['close'].iloc[M2:N2+1].min()
		DIFL3= df['dif'].iloc[M2:N2+1].min()
		CH3 = df['close'].iloc[M2:N2+1].max()
		DIFH3 = df['dif'].iloc[M2:N2+1].max()
		
	print(DIFH1,DIFH2,DIFH3)
	
	zhijiedidunhua = CL1 < CL2 and DIFL1 > DIFL2 and df['macd'].iloc[-2] < 0 and df['dif'].iloc[-1] < 0
	gefengdidunhua = CL1 < CL3 and DIFL3 < DIFL1 < DIFL2 and df['macd'].iloc[-2] < 0 and df['dif'].iloc[-1] < 0
	dibudunhua = (zhijiedidunhua or gefengdidunhua) and df['dif'].iloc[-1] < 0
	
	ref_bool, ref_bool2 = dibudunhua_ref(df, N1_new,M1_new)
	
	didunhua = (ref_bool == False and dibudunhua)
	
	print('ref_bool',ref_bool,dibudunhua,didunhua)
	
	dibujiegou = ref_bool and (abs(df['dif'].iloc[-2]) >= abs(df['dif'].iloc[-1]) * 1.01)
	dijiegouxingcheng = dibujiegou and ref_bool2
	print(dijiegouxingcheng)
	
# didunhua := ((REF(dibudunhua,1) = 0) AND dibudunhua);
# 底部结构 := (REF(dibudunhua,1) AND (ABS(REF(DIF,1)) >= (ABS(DIF) * 1.01)));
# 底结构形成 := ((REF(底部结构,1) = 0) AND 底部结构);

macd(df)
sys.exit()

if df is None:
	print('none')
	sys.exit()
	
df['open']=df['vwap']
print(df.keys())

today=datetime.today().strftime('%Y-%m-%d')
print(today, '\t', symbol)

feed = bt.feeds.PandasData(dataname=df)
cerebro.adddata(feed)
cerebro.addstrategy(TestStrategy)  # Add the trading strategy
cerebro.broker.setcommission(commission = 0.005)
cerebro.addsizer(bt.sizers.PercentSizer, percents=50)
cerebro.addanalyzer(bt.analyzers.AnnualReturn,_name = 'areturn')
teststrat = cerebro.run()  # run it all
print(teststrat[0].analyzers.areturn.get_analysis())
print(df.head(1),'',df.tail(1))
cerebro.plot()  # and plot it with a single command

quote_ctx.close()
sys.exit()

