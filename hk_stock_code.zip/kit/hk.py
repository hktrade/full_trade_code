﻿import json,sys,csv,time,threading,re
import pandas as pd
from idc_tigr import *
import numpy as np
from datetime import datetime,timedelta
from idc import *
from futu import *
min2 = (datetime.now().strftime('%Y-%m-%d %H:%M')+':00')
pd.set_option('display.max_rows', 5000)
pd.set_option('display.max_columns', 5000)
pd.set_option('display.width', 1000)
signal = '';	m_list = [];	df_ps = {}

setdata = read_set()
print('password: \t',setdata.password[0], '\n cash: \t\t',setdata.cash[0], '\n TRD_ENV: \t',setdata.TRD_ENV[0])
TRD_ENV = setdata.TRD_ENV[0]

df_s = read_season()
quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11112)
try:
	trd_ctx = OpenHKTradeContext(host='127.0.0.1', port=11112)
except:
	trd_ctx = OpenHKTradeContext(host='127.0.0.1', port=11112,
	is_encrypt = False, security_firm=SecurityFirm.FUTUSECURITIES)
	
print(quote_ctx,'\n',quote_ctx)

df_09618 = read_config('HK.09618')
print(df_09618,'\n\n')
df_00285 = read_config('HK.00285')
print(df_00285,'\n\n')
df_00753 = read_config('HK.00753')
print(df_00753,'\n\n')
df_00853 = read_config('HK.00853')
print(df_00853,'\n\n')
df_00981 = read_config('HK.00981')
print(df_00981,'\n\n')
df_01579 = read_config('HK.01579')
print(df_01579,'\n\n')
df_00939 = read_config('HK.00939')
print(df_00939,'\n\n')
df_01810 = read_config('HK.01810')
print(df_01810,'\n\n')

# 6862 to 939
df_list = [df_01579,df_00981,df_00853,df_00753,df_00285,df_09618,df_00939,df_01810]
TRD_ENV = 'SIMULATE' # TRD_ENV

def snap_(symbol):
	ret, data = quote_ctx.get_market_snapshot(symbol)
	if ret != RET_OK:
		def_str('error, get_market_snapshot ')
		print(data)
		return([0,0])
	else:
		ask_p = data['ask_price'][0]		
		bid_p = data['bid_price'][0]
		return([ask_p,bid_p])

def hist_order():
	global TRD_ENV
	ret,data_q=trd_ctx.history_order_list_query(trd_env=TRD_ENV,start='',end='')
	if ret!=-1:
		return(data_q)
	else:
		return None
		
def place_(symbol, volume, side):
	global TRD_ENV
	ask_p,bid_p = snap_(symbol)
	if ask_p == 0 or bid_p == 0:
		def_str('ask bid 0');	print('ask bid 0')
		return
	data_err=pd.DataFrame({});	ret=-1	
	if side == 'sell':
		trd_side = TrdSide.SELL
	elif side == 'buy':
		trd_side = TrdSide.BUY
	else:
		def_str('place_ nothing')
		return

	ret,data_err=trd_ctx.place_order(price=ask_p, qty=volume, code=symbol, 
	trd_side=trd_side,  order_type=OrderType.NORMAL, trd_env=TRD_ENV, remark='algo')

	def_str(str(ret)+'  '+symbol+' '+side+' '+str(volume))

	if ret==-1:
		def_str(symbol+' error order '+data_err)
	else:
		print(ret,symbol,trd_side,volume)
	time.sleep(0.02)
	return(ret, data_err)
			

def get_kline( symbol, break_down, over_priced, tp, sl, boll, hand):
	global signal,df_s, m_list, df_ps, TRD_ENV
	print(symbol, break_down, over_priced, tp, sl, boll, hand)
	
	# exist = get_pos_qty(symbol, TRD_ENV)[0] #return(['long', pos_num])
	
	exist, pos_num, tp_amount,tp_rate = get_pos_qty(symbol, TRD_ENV)
	print(exist, pos_num, tp_amount, tp_rate)
	
	if tp_rate != 0 and symbol != 'HK.00939' :
		if exist == 'long' and tp_rate < -sl:
			place_(symbol, hand, 'sell')
			def_str(symbol + '  stop_loss SELL')

		elif exist == 'long' and tp_rate > tp:
			place_(symbol, hand, 'sell')
			def_str(symbol + '  take_profit SELL')
	
	qty = hand;	signal=' ';	 ptx = 0

	ohlc_dict = {'open':'first', 'high':'max', 'low':'min', 'close':'last'}
	def codes(i):
		switcher={3:SubType.K_3M,5:SubType.K_5M,15:SubType.K_15M}
		return (switcher.get(i,"Invalid Symbols"))
	futu_freq = [3,5,15]

	K_type = 15 
	K_type = codes(K_type)

	if symbol == 'HK.00939':
		K_type = SubType.K_DAY;	print('\t\t\t --------------- ',symbol)
	
	ret_sub, err_message = quote_ctx.subscribe(symbol, K_type, subscribe_push=False)
	if ret_sub == RET_OK:
		ret, data3 = quote_ctx.get_cur_kline(symbol, 100, K_type)
		if len(data3)<2:
			def_str(symbol + '  kline error')
			return None

		df_new = szm_hk(data3)
		ptx = szm_ptx(df_new,boll) # without boll selling
		
		if symbol == 'HK.00939':   # with boll selling
			ptx = szm_bbh(df_new,boll);	print('\t\t\t --------------- ',symbol)

		print(df_new.tail(1),'\n\n signal : ',ptx)
	elif ret_sub != RET_OK:
		print(err_message);		def_str(symbol + '  subscribe error')
		return None
	oc = 'oc';	signal_act='act'
	if exist == 'empty' and ptx==-10:
		place_(symbol, hand, 'buy');	oc='open' ;signal_act='buy'
	elif exist == 'long' and ptx==100: # change tp sl
		place_(symbol, hand, 'sell'); oc='close' ;signal_act='sell'
	else:
		signal_act = str(ptx)
		oc = 'else'

	if ptx!=0:
		def_txt(symbol+','+signal_act+','+str(hand)+','+oc)
		print(symbol+','+signal_act+','+str(hand)+','+oc)

####
	if ('1500' <= time.strftime('%H%M') < df_s.end[0]) == False:
		m_list = []

	def_str(symbol+'  '+signal+'  '+str(exist))

	print(symbol+'  '+signal+'  '+str(exist))
	
def end_delta(N):
	today_end = datetime.today().strftime('%Y-%m-%d ') + df_s.end[0][0:2] + ':' + df_s.end[0][-2:]
	return(pd.to_datetime(today_end, format='%Y-%m-%d %H:%M:%S')-timedelta(minutes=N))
def end_comp(b):
	# H_M = datetime.today().strftime('%H%M%S')
	return((datetime.now()-pd.to_datetime(b, format='%Y-%m-%d %H:%M:%S')).seconds/60)
		
def get_df(df_cfg):
	df_new = pd.DataFrame({'symbol':[], 'qty':[]})
	for i in range(len(df_cfg)):
		px = quote_sina(df_cfg['symbol'].iloc[i]);	open_qty = 0
		if px == -1:
			open_qty = -1
		else:
			open_qty = get_qty(df_cfg['open_cap_rate'].iloc[i], px)
		df_new = df_new.append({'symbol':df_cfg['symbol'].iloc[i], 'qty':open_qty},ignore_index=True)
	return(df_new)
	
ret,state=quote_ctx.get_global_state()
if ret!=-1 and len(state)>0:
	print(state['market_hk'])
	if (state['market_hk'] in ['MORNING','AFTERNOON','WAITING_OPEN','REST'])==False:
		def_str('hk 休市');
def t2():
	global min2, df_new, df_ps, df_cfg,cash
	df_cfg = pd.DataFrame({})

	while 1:
		# wk=datetime.today().weekday()
	
		# t = datetime.now().strftime('%H:%M:%S')
		# if ('16:00:00' > t > '09:30:00')==False:
			# print('out of trading hour, continue');		time.sleep(3)
			# continue

		# if '13:00:00' > t > '12:00:00':
			# print('noon break, continue');		time.sleep(3)
			# continue
	
		# if (wk < 5 and time.strftime('%H%M') == df_s.start[0]) == False:
			# if wk==6:
				# print('Sunday return');				time.sleep(3);	continue
			# elif wk==5 and df_s.end[0] <= time.strftime('%H%M'):
				# print('Saturday return');			time.sleep(3);	continue
			# elif (df_s.end[0] <= time.strftime('%H%M') < df_s.start[0])==True:
				# print('out of market , return at ',time.strftime('%H%M'));	time.sleep(3);	continue
				
		# if df_s.start[0] == time.strftime('%H%M'):
			# ret,state=quote_ctx.get_global_state()
			# if ret!=-1 and len(state)>0:
				# print(state['market_hk'])
				# if (state['market_hk'] in ['MORNING','AFTERNOON','WAITING_OPEN','REST'])==False:
					# def_str('hk 休市');
					# continue
			# time.sleep(3)
		# print(df_list)		
		if int(str(datetime.now())[17:19]) % 5 == 0:
		# if 1>0:
			for df_cfg in df_list:
				trade_ret = get_kline(df_cfg.loc['symbol'].value,df_cfg.loc['break_down'].value, 
							df_cfg.loc['over_priced'].value,df_cfg.loc['tp'].value,
							df_cfg.loc['sl'].value,df_cfg.loc['boll'].value,df_cfg.loc['hand'].value)
				time.sleep(5)
		
if __name__ == '__main__':
	f=open(r'str.csv','w');f.write('');f.close()
	f=open(r'error.csv','w');f.write('');f.close()
	print('clear csv')
	df = hist_order()
	print(df, df.keys())#remark
# Index: [] Index(['code', 'stock_name', 'trd_side', 'order_type', 'order_status',
 # 'order_id', 'qty', 'price', 'create_time', 'updated_time', 'dealt_qty', 'dealt_
# avg_price', 'last_err_msg', 'remark', 'time_in_force', 'fill_outside_rth'], dtyp
# e='object')
	# quote_ctx.close()
	# trd_ctx.close()
	if df is not None:
		df.to_csv('setting/hist.csv', index=False, mode='w')
	t2()
	sys.exit()