from datetime import datetime
import backtrader as bt# import backtrader.feeds as btfeeds
import json,os,sys
import requests
import yfinance as yf
import backtrader.feeds as btfeed
import backtrader.indicators as btind
from idc import *
# os.environ["http_proxy"] = "http://127.0.0.1:10809"
# os.environ["https_proxy"] = "http://127.0.0.1:10809"#7890

# Create a subclass of Strategy to define the indicators and logic
old_price=0
dealt_price=0
total_points=0
class TestStrategy(bt.Strategy):
	params = (
		("period", 20),
		("devfactor", 2.2),
		("size", 20),
		("debug", False)
	)

# backtrader index 0 is current, -1 is -2 as df
	# params = dict(period1=5, period2=10, period3=200)
	
	def __init__(self):

		# sma1 = btind.SimpleMovingAverage(self.datas[0], period=self.p.period1)
		# something = sma2 - sma1 + self.data.close
		# sma2 = btind.SimpleMovingAverage(self.datas[0], period=self.p.period2)
		# greater = sma1 > sma2
		
		self.boll = bt.indicators.BollingerBands(period=self.p.period, devfactor=self.p.devfactor)
		print(self.data.close[0])
		self.sma200 = btind.SMA(period=100)

		# self.vwap = self.data.open
		
		self.signal_bot = btind.CrossOver(self.data.close, self.boll.lines.bot)
		self.signal_top = btind.CrossOver(self.data.close, self.boll.lines.top)
		self.signal_mid = btind.CrossOver(self.data.close, self.boll.lines.mid)
		
	def next(self): #self.data.low < self.boll.lines.bot  and self.data.close[0] < self.sma200
		global old_price,dealt_price,total_points
		if not self.position:
			if self.signal_mid > 0 : # self.data.close > self.data.open:# bad for hk stk
			# if self.signal_bot > 0:
				# print(self.data.close[-3],type(self.data.close[-3]))
				# old_price = self.data.close[0]
				# self.buy()
				
				if dealt_price !=0 and dealt_price - self.data.close[0] > self.data.close[0]*0.08:
					print('break_down',self.data.close[0])
				
				else:
					if self.data.close[0] - dealt_price < self.data.close[0]*0.12:
						self.buy()
					elif dealt_price != 0:
						print('over_priced',self.data.close[0])
						old_price = 0
					elif dealt_price==0:
						self.buy()
					old_price = self.data.close[0]
					
		else:#self.signal_top > 0 and 
			if old_price !=0 and round((self.data.close[0]-old_price)/old_price,3) >= 0.05:
				self.close()
				total_points += round((self.data.close[0]-old_price)/old_price,3)
				dealt_price = old_price
				print(old_price,self.data.close[0], round((self.data.close[0]-old_price)/old_price,3), round(total_points,3),
				round((self.data.close[0]-old_price)/old_price,3) >= -0.05)
				
			if round((self.data.close[0]-old_price)/old_price,3) <= -0.02:
				self.close()
				total_points += round((self.data.close[0]-old_price)/old_price,4)
				dealt_price = old_price
				print(old_price,self.data.close[0], round((self.data.close[0]-old_price)/old_price,3), round(total_points,3))
				
			
				# total_points += self.data.close[0]-old_price
				# print(old_price,self.data.close[0], self.data.close[0]-old_price, total_points)
				# dealt_price = old_price
				# self.close()
			# elif self.data.high > self.boll.lines.top and self.data.close[0] > self.sma200:
				# self.close()
				
			# elif self.data.close[0] < old_price - 40:
				# total_points += self.data.close[0]-old_price
				# print(old_price,self.data.close[0], self.data.close[0]-old_price, total_points)
				# dealt_price = old_price
				# self.close()

#for 700
	# def next(self):
		# if not self.position:
			# if self.signal > 0 and self.data.high > self.boll.lines.mid:
				# self.buy()
		# else:
			# if self.data.low > self.boll.lines.top and self.data.open > self.boll.lines.mid:
				# self.close()

cerebro = bt.Cerebro()  # create a "Cerebro" engine instance
cerebro.broker.setcash(100000)

symbol = 'HK.00700'
if len(sys.argv)>2:
	df = get_bar_min_tdd(sys.argv[1], int(sys.argv[2]))
	symbol = sys.argv[1]
else:
	df = get_bar_min_tdd(symbol, 3)

# print(len(df),df.tail(5))

if df is None:
	print('none')
	sys.exit()
	
# df['open']=df['vwap']
print(df.keys())

today=datetime.today().strftime('%Y-%m-%d')
print(today, '\t', symbol)

feed = bt.feeds.PandasData(dataname=df)
cerebro.adddata(feed)
cerebro.addstrategy(TestStrategy)  # Add the trading strategy
cerebro.broker.setcommission(commission = 0)
cerebro.addsizer(bt.sizers.PercentSizer, percents=50)
cerebro.addanalyzer(bt.analyzers.AnnualReturn,_name = 'areturn')
teststrat = cerebro.run()  # run it all
print(teststrat[0].analyzers.areturn.get_analysis())
# print(df.head(1),'',df.tail(1))
cerebro.plot()  # and plot it with a single command

quote_ctx.close()
sys.exit()

