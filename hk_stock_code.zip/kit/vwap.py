from futu import *
import pandas as pd
import mplfinance as mpf
import math

quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11112)
symbol = 'HK.00700'
ret_sub, err_message = quote_ctx.subscribe(symbol, [SubType.K_3M], subscribe_push=False)
if ret_sub == RET_OK:
	ret, df = quote_ctx.get_cur_kline(symbol, 111, SubType.K_3M)

df.set_index(['time_key'], inplace=True)
df.index = pd.to_datetime(df.index)
df.index.name = 'time_key'

# for i in range(len(df)):
	# df.at[i, ['open']] = df['turnover'].iloc[0:i].sum() / df['volume'].iloc[0:i].sum()
	
# print(df.open)
	
# AVGPRICE:=TOTALAMOUNT/TOTALVOL;
# VWAP:IF(AVGPRICE=0,(C+H+L)/3,AVGPRICE),COLORYELLOW;

# df['AVGPRICE'] = df.turnover/df.volume
# df['VWAP'] = df['AVGPRICE']

# df['VWAP2'] = (df.close + df.high + df.low)/3
# print(df['VWAP'].tail(5))
# print(df['VWAP2'].tail(5))



# print(df.keys())
# print(df[df['AVGPRICE']==0])

# from here = https://www.tradingtechnologies.com/xtrader-help/x-study/technical-indicator-definitions/volume-weighted-average-price-vwap/

df['VWAP'] = df.turnover.cumsum() / df.volume.cumsum()

print(df['VWAP'])


# df['VWAP_MEAN_DIFF'] = ((df.high + df.low) / 2) - df.VWAP
# df['SQ_DIFF'] = df.VWAP_MEAN_DIFF.apply(lambda x: math.pow(x, 2))
# df['SQ_DIFF_MEAN'] = df.SQ_DIFF.expanding().mean()
# df['STDEV_TT'] = df.SQ_DIFF_MEAN.apply(math.sqrt)

# stdev_multiple_1 = 1.28
# stdev_multiple_2 = 2.01
# stdev_multiple_3 = 2.51

# df['STDEV_1'] = df.VWAP + stdev_multiple_1 * df['STDEV_TT']
# df['STDEV_N1'] = df.VWAP - stdev_multiple_1 * df['STDEV_TT']

addplot  = [
    mpf.make_addplot(df['VWAP']),
    # mpf.make_addplot(df['STDEV_1']),
    # mpf.make_addplot(df['STDEV_N1']),
]

mpf.plot(df, type='candle', addplot=addplot)


quote_ctx.close()
sys.exit()

# def calc_vwap(marketDataTable):
    # n = len(marketDataTable) - 1
    # total_sum = 0.0
    # volume_sum = 0
    # for i in range(1, n + 1):
        # high_price = float(marketDataTable[i][9])
        # low_price = float(marketDataTable[i][10])
        # price = (high_price + low_price) / 2
        # volume = int(marketDataTable[i][11])
        # total_sum += price * volume
        # volume_sum += volume
    # return total_sum / volume_sum